﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class ProductoB : Producto
    {
        private short alto;
        private short ancho;
        private short largo;

        public ProductoB()
        { }

        public ProductoB(string descripcion, short largo, short alto, short ancho)
            : base(descripcion)
        {
            this.alto = alto;
            this.largo = largo;
            this.ancho = ancho;
        }


        public short Alto
        {
            get { return this.alto; }
        }
        
        public short Ancho
        {
            get { return this.ancho; }
        }

        public short Largo
        {
            get { return this.largo; }
        }


        public bool ValidarDimensiones()
        {
            return ((this.largo + this.ancho + this.alto) <= 100);
        }

        private int CalcularVolumen()
        {
            return (this.largo * this.ancho * this.alto);
        }

        public override string Mostrar()
        {
            return String.Format("{0}, Tipo: {1}, ANCHO: {2}, ALTO: {3}, LARGO: {4}, VOLUMEN: {5}",
                base.Mostrar(), "B", this.ancho, this.alto, this.largo, CalcularVolumen());
        }
    }
}
