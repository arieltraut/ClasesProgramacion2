﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;


namespace Entidades
{

    public class ProductoA : Producto
    {
        private short diametro;
        private Material material;


        public ProductoA()
        { }
        
        public ProductoA(string descripcion, short diametro, Material material)
            : base(descripcion)
        {
            this.diametro = diametro;
            this.material = material;
        }


        public short Diametro
        {
            get { return this.diametro; }
        }

        public Material Material
        {
            get { return this.material; }
            set
            {
                if (ValidarMaterial(value))
                    this.material = value;
            }

        }




        public override string Mostrar()
        {
            return String.Format("{0}, Tipo: {1}, DIAMETRO: {2}, MATERIAL: {3}",
                base.Mostrar(), "A", this.diametro, this.material);
        }

        public bool ValidarMaterial(Material unMaterial)
        {
            bool retorno = false;
            if(unMaterial == Entidades.Material.Aluminio && this.diametro <= 10)
                retorno = true;
            else if(unMaterial == Entidades.Material.Caucho && this.diametro <= 15)
                retorno = true;
            else if(unMaterial == Entidades.Material.Plastico)
                retorno = true;
            else
                throw new MaterialException(String.Format("No se puede fabricar una pieza de {0} y diámetro de {1} centímetros.",
                    this.material,this.diametro));            
            return retorno;
        }

        public bool ValidarDimensiones()
        {
            return ((this.diametro % 2) == 0 && (this.diametro >= 30) && (this.diametro <= 50));
        }
    }
}
