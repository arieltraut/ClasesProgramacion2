﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Entidades
{
    public class ProductoDAO
    {
        #region Atributos
        private static SqlConnection _conexion;
        private static SqlCommand _comando;
        private string cadenaDeConexion = "Data Source=.\SQLEXPRESS;Initial Catalog=final-20180712;Integrated Security=True";
        #endregion


        #region Constructores
        public ProductoDAO()
        {
            // CREO UN OBJETO SQLCONECTION
            ProductoDAO._conexion = new SqlConnection(@cadenaDeConexion); //Properties.Settings.Default.conexion
            // CREO UN OBJETO SQLCOMMAND"
            ProductoDAO._comando = new SqlCommand();
            // INDICO EL TIPO DE COMANDO
            ProductoDAO._comando.CommandType = System.Data.CommandType.Text;
            // ESTABLEZCO LA CONEXION
            ProductoDAO._comando.Connection = ProductoDAO._conexion;
        }
        #endregion

        #region Metodos
        #region Obtiene toda la Tabla
        public List<Producto> ObtenerProductos()
        {
            bool TodoOk = false;
            List<Producto> lista = new List<Producto>();

            try
            {
                // LE PASO LA INSTRUCCION SQL
                ProductoDAO._comando.CommandText = "SELECT * FROM Productos";

                // ABRO LA CONEXION A LA BD
                ProductoDAO._conexion.Open();

                // EJECUTO EL COMMAND                 
                SqlDataReader oDr = ProductoDAO._comando.ExecuteReader();

                // MIENTRAS TENGA REGISTROS...
                while (oDr.Read())
                {
                    // ACCEDO POR NOMBRE O POR INDICE
                    lista.Add(new Producto(int.Parse(oDr["ProductID"].ToString()), oDr["Name"].ToString(), oDr["Apellido"].ToString()));ç
                    // ????????
                }

                //CIERRO EL DATAREADER
                oDr.Close();

                TodoOk = true;
            }

            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (TodoOk)
                    ProductoDAO._conexion.Close();
            }
            return lista;
        }
        #endregion


        #region Insertar
        public static bool Insertar(Producto p)
        {
            if(p is ProductoA)
            {
                string sql = String.Format("INSERT INTO Productos (descripcion,diametro,material) VALUES('{0}','{1}','{2}');",
                    p.Descripcion, ((ProductoA)p).Diametro, ((ProductoA)p).Material);
            }

            return EjecutarNonQuery(sql); //??
        }
        #endregion

        private static bool EjecutarNonQuery(string sql)
        {
            bool todoOk = false;
            try
            {
                // LE PASO LA INSTRUCCION SQL
                ProductoDAO._comando.CommandText = sql;

                // ABRO LA CONEXION A LA BD
                ProductoDAO._conexion.Open();

                // EJECUTO EL COMMAND
                ProductoDAO._comando.ExecuteNonQuery();

                todoOk = true;
            }
            catch (Exception e)
            {
                todoOk = false;
            }
            finally
            {
                if (todoOk)
                    ProductoDAO._conexion.Close();
            }
            return todoOk;
        }
        #endregion

    }
}
