﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Entidades
{
    public enum Material
    { Plastico, Aluminio, Caucho }

    public abstract class Producto
    {
        // Delegado del evento
        public delegate void ProductoTerminado(object sender, EventArgs e);
        // Evento del tipo del delegado
        public event ProductoTerminado InformarProductoTerminado;

        private string descripcion;



        public Producto()
        { }
        
        public Producto(string descripcion)
        {
            this.descripcion = descripcion;

        }



       
        public string Descripcion
        {
            get { return this.descripcion; }
        }



        public void Elaborar()
        {
            ProductoDAO guardar = new ProductoDAO();
            guardar.ObtenerProductos();
            InformarProductoTerminado(this, new EventArgs());
        }

        public virtual string Mostrar()
        {           
            return String.Format("DESCRIPCION: {0}", this.descripcion);
        }

    }
}
